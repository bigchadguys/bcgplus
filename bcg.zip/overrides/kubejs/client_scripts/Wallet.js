ItemEvents.tooltip((e) => {
  e.add("kubejs:wallet", Text.of("§6Right-Click §7to deposit §aEmeralds§7!"));
  e.add(
    "kubejs:wallet",
    Text.of("§6Shift Right-Click §7to withdraw §aEmeralds§7!")
  );
});
