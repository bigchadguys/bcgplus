ServerEvents.recipes((e) => {
  e.shaped(Item.of("kubejs:wallet", 1), [" L ", "L L", " L "], {
    L: "minecraft:leather",
  });
});
