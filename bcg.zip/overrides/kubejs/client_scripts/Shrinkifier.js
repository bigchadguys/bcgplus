ItemEvents.tooltip((e) => {
  e.add("kubejs:shrinkifier", Text.of("§7Shrink yourself!"));
});
