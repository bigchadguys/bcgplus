ItemEvents.tooltip((e) => {
  e.add("cobbreeding:pokemon_egg", Text.of("§7Right click to learn more!"));
});
